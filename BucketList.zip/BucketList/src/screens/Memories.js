import styles from "../StyleSheet";
import React from 'react';
import {  Container, View, Button } from "react-native";

class Memories extends React.Component{


render() {
    return (
        <View style={styles.container}>
        
        </View>
    );
  }
}

export default Memories;

