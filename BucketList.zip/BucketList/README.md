This is the branch is for the combining the separate branches to create the full working application needed for 
iteration 1

the first commit is the combination of the google-api and login-signup branches - (CURRENT VERSION) 
